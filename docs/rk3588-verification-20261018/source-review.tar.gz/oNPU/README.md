# oNPU

oNPU is a local web app for managing and chatting with GGUF language models on Rockchip boards. It uses an existing [tinygrad](https://github.com/tinygrad/tinygrad) checkout as its inference backend. Mali OpenCL is the default execution profile. Optional NPU assistance is measured per inference phase; CPU inference remains available.

## Run

Requirements: Python 3.11+, [uv](https://docs.astral.sh/uv/), and a working tinygrad checkout.

```bash
cd ~/oNPU
uv sync --python ~/tinygrad/.venv/bin/python
./run.sh --backend ~/tinygrad
```

Open <http://127.0.0.1:8080>. Import a local GGUF model or download one from the app. Project data is stored in `.data` by default; use `--data-dir` to choose another location.

The API provides OpenAI-compatible chat completions at `/v1/chat/completions`. See <http://127.0.0.1:8080/docs> while the app is running for the API reference.

## GPU-first serving and optional NPU assistance

Use `~/tinygrad` on its `oNPU` branch as the backend. It contains the Mali queue
workaround and the retained Rockchip kernels; no separate OpenCL checkout or
reference worktree is needed.

Choose **Mali GPU · OpenCL** for normal loading. The prefill and decode NPU
controls default to **Off**. **Auto** compares the original layer with the NPU
path, including transfers, verifies numerical agreement, and selects an NPU
candidate only when its measured median is at least 10% faster. Most surrounding
operations remain on the GPU. Bulk prefill, single-row decode, and the final
vocabulary projection are measured separately.

The **Rockchip NPU + CPU** profile prepares FP16 weights and places supported
dense decode projections on the NPU. Its prefill control defaults to Auto in
the load form; Auto selects supported prefill work only when it wins. Other
operations use the CPU. It is an
inference profile, not a claim that the complete model runs on the NPU or that
quantized GGUF weights execute with native quantized arithmetic.

A GPU-only model and a different NPU-assisted model can remain loaded and serve
requests concurrently. Each model has its own worker, request admission, KV
state and cancellation. Use its **Chat** button to select it; API requests route
by `model` ID. Unloading one model preserves the other. NPU assistance on a GPU
model reserves the same physical NPU, so disable assistance when assigning that
NPU to a separate model.

For explicit API loading:

```bash
curl http://127.0.0.1:8080/api/models/GPU_MODEL_ID/load \
  -H 'Content-Type: application/json' \
  -d '{"profile":"CL","context":512,"realize":true}'
curl http://127.0.0.1:8080/api/models/SMALL_MODEL_ID/load \
  -H 'Content-Type: application/json' \
  -d '{"profile":"ROCKCHIP","context":512,"realize":true,"npu_prefill":"auto"}'
```

For measured assistance on one GPU model, add `"npu_prefill":"auto"` and/or
`"npu_decode":"auto"` to its load options. Actual execution devices and placement
measurements are reported in `/api/status`. Saved user profile preferences remain
in effect; select OpenCL to change an existing CPU preference.

CPU/NPU serving selects a suitable prefill chunk and reuses its prepared graph.
Cold preparation currently takes about 150 seconds while compiling prompt sizes
and greedy/sampled paths; steady-state latency excludes that one-time load.
The tested Qwen3-0.6B FP16 path beats matched RKLLM prefill and decode at 128 and
256 input tokens. This does not establish W8A8 or all-model performance. See the
[verification record](VERIFICATION.md) for measurements and limitations.

## Development

```bash
uv sync --extra test --python ~/tinygrad/.venv/bin/python
.venv/bin/python -m pytest -q
```

With a ready model, exercise GPU serving, streaming and cancellation through the real API:

```bash
.venv/bin/python scripts/smoke.py --model MODEL_ID --profile CL --context 1024
```

See [VERIFICATION.md](VERIFICATION.md) for current device and backend limitations, and [THIRD_PARTY_NOTICES](THIRD_PARTY_NOTICES) for attribution.
