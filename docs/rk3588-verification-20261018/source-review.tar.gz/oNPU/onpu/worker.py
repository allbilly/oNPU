"""Single-owner tinygrad inference worker. JSON lines are the only stdout protocol.

All model operations run on one thread; the input thread only queues commands and
sets cancellation flags. No changes are made to the user's tinygrad checkout.
"""
from __future__ import annotations

import argparse
import itertools
import json
import os
import queue
import sys
import threading
import time
import traceback
from types import SimpleNamespace
from pathlib import Path


class Cancelled(Exception):
    pass


def prefill_chunks(context: int) -> list[int]:
    return sorted({min(32, context), *(size for size in (64, 128, 256) if size <= context)})


def prefill_chunk(remaining: int, context: int) -> int:
    if remaining <= 1:
        return 1
    buckets = prefill_chunks(context)
    return next((size for size in buckets if remaining <= size), buckets[-1])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True)
    parser.add_argument("--context", type=int, required=True)
    parser.add_argument("--realize", type=int, default=1)
    parser.add_argument("--probe", action="store_true")
    args = parser.parse_args()
    protocol = sys.stdout
    sys.stdout = sys.stderr
    write_lock = threading.Lock()

    def emit(event: str, **data):
        with write_lock:
            protocol.write(json.dumps({"event": event, **data}, ensure_ascii=False) + "\n")
            protocol.flush()

    try:
        import tinygrad
        from tinygrad import Device, Tensor
        from tinygrad.helpers import GlobalCounters
        if args.probe:
            if os.environ.get("ONPU_PROFILE") == "ROCKCHIP":
                from tinygrad.llm.kernels.rockchip import pack_weight, packed_matmul
                weight = pack_weight(Tensor.ones(32, 32, device="CPU")).realize()
                result = packed_matmul(Tensor.ones(1, 32, device="CPU"), weight, 32).tolist()
                if result != [[32.0] * 32]:
                    raise ValueError("NPU matmul smoke test failed")
                emit("probe", available=True, device="ROCKCHIP", name="RK3588 NPU dense projections + CPU")
                return
            result = (Tensor([1., 2., 3.]) + 1).tolist()
            if result != [2., 3., 4.]:
                raise ValueError("Tensor smoke test failed")
            name = Device.DEFAULT
            if name.startswith("CL"):
                device = Device[name]
                name = device.device_name
            emit("probe", available=True, device=Device.DEFAULT, name=name,
                 driver=getattr(Device[Device.DEFAULT], "driver_version", None))
            return

        from jinja2.sandbox import ImmutableSandboxedEnvironment
        from tinygrad import nn
        from tinygrad.llm.cli import SimpleTokenizer, FallbackTemplate
        from tinygrad.llm.model import Transformer
        from tinygrad.llm.serve import Handler, normalize_messages

        start = time.perf_counter()
        emit("state", state="loading", message="Reading model weights")
        model, kv = Transformer.from_gguf(args.model, args.context, realize=bool(args.realize))
        placement = None
        npu_prefill, npu_decode = os.environ.get("ONPU_NPU_PREFILL", "off"), os.environ.get("ONPU_NPU_DECODE", "off")
        if npu_prefill != "off" or npu_decode != "off":
            from tinygrad.llm.kernels.rockchip import configure
            cpu_npu = Device.DEFAULT == "CPU"
            if cpu_npu and hasattr(os, "sched_getaffinity"):
                cores = os.sched_getaffinity(0).intersection({4, 5, 6, 7})
                if cores:
                    os.sched_setaffinity(0, cores)
            emit("state", state="preparing", message="Preparing NPU weights and measuring optional placement")
            placement = configure(model, prefill=npu_prefill, decode=npu_decode, tile_columns=24576,
                                  fuse_projections=True, cpu_attention=cpu_npu,
                                  native_replay=cpu_npu, fused_ffn=cpu_npu, fused_qkv=cpu_npu,
                                  cpu_norm=cpu_npu, split_down=cpu_npu)
            if not placement["decode_layers"] and not placement["prefill_layers"]:
                if os.environ.get("ONPU_PROFILE") == "ROCKCHIP":
                    raise ValueError("This model has no supported NPU projections. Choose the GPU or CPU profile.")
                if placement["layers"]:
                    Device["ROCKCHIP"].finalize()
        tok = SimpleTokenizer.from_gguf_kv(kv)
        template = FallbackTemplate(tok)
        if source := kv.get("tokenizer.chat_template"):
            env = ImmutableSandboxedEnvironment()
            env.filters["tojson"] = lambda obj, **kwargs: json.dumps(obj, **kwargs)
            env.globals.update(raise_exception=lambda msg: (_ for _ in ()).throw(ValueError(msg)),
                               strftime_now=lambda fmt: time.strftime(fmt),
                               bos_token=tok.decode([tok.bos_id]) if tok.bos_id is not None else "", eos_token=tok.decode([tok.eos_id]))
            template = env.from_string(source)

        commands: queue.Queue = queue.Queue()
        cancellations: dict[str, threading.Event] = {}
        active_cancel = threading.Event()

        # Check between prefill chunks and decode operations, rather than waiting
        # for a complete prompt to produce its first token before honoring Stop.
        def checkpoint(jit):
            def run(*a, **kw):
                if active_cancel.is_set():
                    raise Cancelled()
                return jit(*a, **kw)
            return run
        for attr in ("prefill_jit", "rollout_jit", "greedy_prefill_jit", "greedy_rollout_jit"):
            if hasattr(model, attr):
                setattr(model, attr, checkpoint(getattr(model, attr)))

        adaptive_prefill = bool(placement and placement.get("native_replay") and placement["prefill_layers"])
        if adaptive_prefill:
            original_generate = model.generate
            def generate(tokens, chunk_size=None, **kwargs):
                if chunk_size is None:
                    chunk_size = prefill_chunk(len(tokens) - model.get_start_pos(tokens), model.max_context)
                return original_generate(tokens, chunk_size=chunk_size, **kwargs)
            model.generate = generate

        emit("state", state="preparing", message="Compiling and warming the model")
        model.warmup()
        # Warm the separate sampling/greedy prompt and token graphs before ready.
        # Optional CPU/NPU placement also prepares each adaptive prompt size.
        chunks_to_warm = prefill_chunks(model.max_context) if adaptive_prefill else [min(32, model.max_context)]
        native = bool(placement and placement.get("native_replay") and (placement["decode_layers"] or placement["prefill_layers"]))
        stages = len(chunks_to_warm) * 2
        stage = 0
        for temperature in (0.0, 0.6):
            for chunk in chunks_to_warm:
                stage += 1
                emit("state", state="preparing", message=f"Preparing inference ({stage}/{stages})")
                prompt_length = min(chunk, model.max_context - 2)
                for _ in range(4 if native else 2):
                    model._cached_tokens = []
                    list(itertools.islice(model.generate([0] * prompt_length, chunk_size=chunk, temperature=temperature), 2))
        model._cached_tokens = []
        actual_device = nn.state.get_parameters(model)[0].device
        base_device = actual_device
        if placement and (placement["decode_layers"] or placement["prefill_layers"]):
            actual_device = f"{base_device}+ROCKCHIP"
        handler = object.__new__(Handler)
        handler.server = SimpleNamespace(model=model, tok=tok)
        emit("ready", device=actual_device, context=model.max_context, name=kv.get("general.name", args.model),
             load_seconds=time.perf_counter() - start, weight_bytes=GlobalCounters.mem_used,
             base_device=base_device, placement=placement, backend_path=str(Path(tinygrad.__file__).resolve().parents[1]))

        def input_loop():
            try:
                for line in sys.stdin:
                    command = json.loads(line)
                    if command["op"] == "cancel":
                        if flag := cancellations.get(command["id"]):
                            flag.set()
                    else:
                        if command["op"] == "generate":
                            cancellations[command["id"]] = threading.Event()
                        commands.put(command)
            finally:
                for flag in list(cancellations.values()):
                    flag.set()
                commands.put({"op": "shutdown"})

        threading.Thread(target=input_loop, daemon=True).start()
        while True:
            command = commands.get()
            if command["op"] == "shutdown":
                return
            if command["op"] != "generate":
                continue
            key, body = command["id"], command["body"]
            active_cancel = cancellations[key]
            chunks = None
            started = first = last = None
            try:
                prep = time.perf_counter()
                normalize_messages(body["messages"])
                rendered = template.render(messages=body["messages"], tools=body.get("tools"), add_generation_prompt=True,
                                           preserve_thinking=True, enable_thinking=body.get("enable_thinking", False))
                ids = tok.encode(rendered)
                limit = body["max_tokens"]
                if len(ids) + limit > model.max_context:
                    raise ValueError(f"Prompt ({len(ids)} tokens) + reply limit ({limit}) exceeds context ({model.max_context}). "
                                     "Reduce the reply limit or start a new chat.")
                cached = model.get_start_pos(ids)
                npu_before = Device["ROCKCHIP"].submit_count if placement else 0
                if active_cancel.is_set():
                    raise Cancelled()
                emit("started", id=key, prompt_tokens=len(ids), cached_tokens=cached, preparation_seconds=time.perf_counter() - prep)
                started = time.perf_counter()
                chunks = handler.run_model(ids.copy(), body["model"], include_usage=True, max_tokens=limit,
                                           temperature=body["temperature"], reasoning=rendered.rstrip().endswith("<think>"))
                usage = None
                for chunk in chunks:
                    if active_cancel.is_set():
                        raise Cancelled()
                    if chunk.get("usage"):
                        usage = chunk["usage"]
                    for choice in chunk.get("choices", []):
                        if any(choice.get("delta", {}).get(field) for field in ("content", "reasoning_content", "tool_calls")):
                            first = first or time.perf_counter()
                            last = time.perf_counter()
                    emit("chunk", id=key, data=chunk)
                ended = time.perf_counter()
                tokens = (usage or {}).get("completion_tokens", 0)
                # TTFT measures the first emitted text; token timings are not fabricated
                # from the role event, which is emitted before inference begins.
                elapsed = ended - started
                metrics = {"prompt_tokens": len(ids), "cached_tokens": cached, "completion_tokens": tokens,
                           "ttft_ms": (first - started) * 1000 if first else None, "total_seconds": elapsed,
                           "decode_tps": (tokens - 1) / (last - first) if tokens > 1 and first and last and last > first else None,
                           "prefill_tps": (len(ids) - cached) / (first - started) if first and first > started else None,
                           "device": actual_device, "allocated_bytes": GlobalCounters.mem_used}
                if placement:
                    metrics["npu_submissions"] = Device["ROCKCHIP"].submit_count - npu_before
                emit("done", id=key, metrics=metrics)
            except Cancelled:
                model._cached_tokens = []
                emit("cancelled", id=key)
            except ValueError as exc:
                model._cached_tokens = []
                emit("error", id=key, message=str(exc), status=400)
            except Exception as exc:
                model._cached_tokens = []
                traceback.print_exc()
                emit("error", id=key, message=str(exc), status=500)
            finally:
                if chunks is not None:
                    chunks.close()
                cancellations.pop(key, None)
    except Exception as exc:
        traceback.print_exc()
        emit("fatal", message=str(exc))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
