from onpu.worker import prefill_chunk, prefill_chunks


def test_prefill_chunks_fit_context_and_keep_single_token_decode_small():
    assert prefill_chunks(512) == [32, 64, 128, 256]
    assert prefill_chunks(96) == [32, 64]
    assert prefill_chunks(16) == [16]
    for remaining, expected in [(1, 1), (17, 32), (33, 64), (65, 128), (129, 256), (400, 256)]:
        assert prefill_chunk(remaining, 512) == expected
    assert prefill_chunk(80, 96) == 64
