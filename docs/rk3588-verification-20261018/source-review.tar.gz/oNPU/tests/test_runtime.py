import asyncio
import time

import pytest

from onpu.runtime import EngineError, Runtime, RuntimePool
from onpu.store import Store


def test_single_request_admission_and_cancellation(tmp_path):
    async def run():
        store = Store(tmp_path / "data")
        runtime = Runtime(store, tmp_path)
        runtime.state = "ready"
        commands = []
        async def send(command):
            commands.append(command)
            if command["op"] == "generate":
                await runtime.requests[command["id"]].put({"event": "started", "prompt_tokens": 5})
        runtime.send = send
        try:
            key, channel, first = await runtime.generate({"model": "test"})
            assert first["prompt_tokens"] == 5
            with pytest.raises(EngineError, match="busy"):
                await runtime.generate({"model": "test"})
            await runtime.cancel(key)
            assert commands[-1] == {"op": "cancel", "id": key}
            runtime.active = None
            await runtime.release(key)
            assert key not in runtime.requests
        finally:
            store.close()
    asyncio.run(run())


def test_stalled_startup_becomes_recoverable_error(tmp_path):
    async def run():
        store = Store(tmp_path / "data")
        runtime = Runtime(store, tmp_path)
        runtime.state = "preparing"
        runtime.load_started = time.monotonic() - 500
        try:
            await runtime.check_startup_timeout()
            assert runtime.state == "error"
            assert "timed out" in runtime.message
            await runtime.unload()
            assert runtime.state == "idle"
        finally:
            store.close()
    asyncio.run(run())


def test_context_error_is_reported_before_streaming(tmp_path):
    async def run():
        store = Store(tmp_path / "data")
        runtime = Runtime(store, tmp_path)
        runtime.state = "ready"
        async def send(command):
            if command["op"] == "generate":
                await runtime.requests[command["id"]].put({"event": "error", "message": "Context exceeded", "status": 400})
                runtime.active = None
                runtime.state = "ready"
        runtime.send = send
        try:
            with pytest.raises(EngineError) as exc:
                await runtime.generate({"model": "test"})
            assert exc.value.status == 400
            assert runtime.requests == {}
        finally:
            store.close()
    asyncio.run(run())


def test_gpu_and_npu_sessions_route_and_cancel_independently(tmp_path, monkeypatch):
    async def load(self, model, options):
        self.model, self.profile, self.options, self.state = model, options["profile"], options, "ready"
    monkeypatch.setattr(Runtime, "load", load)

    async def run():
        store = Store(tmp_path / "data")
        pool = RuntimePool(store, tmp_path)
        try:
            await pool.load({"id": "gpu", "name": "GPU model"}, {"profile": "CL"})
            gpu = pool.sessions["gpu"]
            await pool.load({"id": "npu", "name": "NPU model"}, {"profile": "ROCKCHIP"})
            npu = pool.sessions["npu"]
            commands = {"gpu": [], "npu": []}
            for name, session in pool.sessions.items():
                async def send(command, name=name, session=session):
                    commands[name].append(command)
                    if command["op"] == "generate":
                        await session.requests[command["id"]].put({"event": "started", "prompt_tokens": 5})
                session.send = send
            gpu_key, _, _ = await pool.generate({"model": "gpu"})
            npu_key, _, _ = await pool.generate({"model": "npu"})
            assert gpu.active == gpu_key and npu.active == npu_key
            with pytest.raises(EngineError, match="busy"):
                await pool.generate({"model": "gpu"})
            await pool.cancel(npu_key)
            assert commands["npu"][-1] == {"op": "cancel", "id": npu_key}
            assert len(commands["gpu"]) == 1
            gpu.active = npu.active = None
            await pool.release(gpu_key)
            await pool.release(npu_key)
            assert not gpu.requests and not npu.requests
            gpu_state = gpu.state
            await pool.unload("npu")
            assert pool.sessions == {"gpu": gpu}
            assert gpu.state == gpu_state
        finally:
            await pool._stop()
            store.close()
    asyncio.run(run())


def test_npu_owner_conflict_preserves_loaded_models(tmp_path, monkeypatch):
    async def load(self, model, options):
        self.model, self.profile, self.options, self.state = model, options["profile"], options, "ready"
    monkeypatch.setattr(Runtime, "load", load)

    async def run():
        store = Store(tmp_path / "data")
        pool = RuntimePool(store, tmp_path)
        try:
            await pool.load({"id": "npu", "name": "Small model"}, {"profile": "ROCKCHIP"})
            with pytest.raises(EngineError, match="already assigned"):
                await pool.load({"id": "gpu", "name": "GPU model"}, {"profile": "CL", "npu_decode": "auto"})
            assert list(pool.sessions) == ["npu"]
            assert pool.sessions["npu"].state == "ready"
        finally:
            await pool._stop()
            store.close()
    asyncio.run(run())


def test_unused_npu_auto_placement_does_not_reserve_second_model(tmp_path, monkeypatch):
    async def load(self, model, options):
        self.model, self.profile, self.options, self.state = model, options["profile"], options, "ready"
    monkeypatch.setattr(Runtime, "load", load)

    async def run():
        store = Store(tmp_path / "data")
        pool = RuntimePool(store, tmp_path)
        try:
            await pool.load({"id": "gpu", "name": "GPU model"}, {"profile": "CL", "npu_decode": "auto"})
            pool.sessions["gpu"].info["placement"] = {"decode_layers": 0, "prefill_layers": 0}
            await pool.load({"id": "npu", "name": "Small model"}, {"profile": "ROCKCHIP"})
            assert set(pool.sessions) == {"gpu", "npu"}
        finally:
            await pool._stop()
            store.close()
    asyncio.run(run())
