"""Benchmark raw-token requests against a matched RKLLM log, with explicit NPU placement.

Use identical checkpoint, input IDs, precision, affinity and clocks for both engines.
Loading, packing, full warmups and KV reset are excluded. EOS does not stop generation.
"""
from __future__ import annotations
import argparse, hashlib, itertools, json, os, statistics, time
from collections import Counter
from pathlib import Path


def observe(event:str, index:int): pass  # Optional external diagnostic observer; no production execution changes.


def clocks():
  paths = [*Path('/sys/class/devfreq').glob('*/cur_freq'),
           *Path('/sys/devices/system/cpu/cpufreq').glob('policy*/scaling_cur_freq')]
  return {str(path):path.read_text().strip() for path in paths}


def stock_ids(path, count):
  rows = []
  for line in path.read_text().splitlines():
    try: row = json.loads(line)
    except json.JSONDecodeError: continue
    if isinstance(row,dict) and row.get('event')=='run': rows.append(row['generated_ids'][:count])
  if not rows or len(rows[0])!=count or any(row!=rows[0] for row in rows):
    raise ValueError('Stock reference needs consistent complete token sequences')
  return rows[0]


def main():
  parser = argparse.ArgumentParser(description=__doc__)
  parser.add_argument('--checkpoint',type=Path,required=True)
  parser.add_argument('--input',type=Path,required=True)
  parser.add_argument('--device',choices=['CPU','CL'],default='CPU')
  parser.add_argument('--prefill',choices=['off','auto','on'],default='on')
  parser.add_argument('--decode',choices=['off','auto','on'],default='on')
  parser.add_argument('--tile-columns',type=int,default=4096)
  parser.add_argument('--fuse-projections',action='store_true')
  parser.add_argument('--cpu-attention',action='store_true')
  parser.add_argument('--native-replay',action='store_true')
  parser.add_argument('--fused-ffn',action='store_true')
  parser.add_argument('--split-down',action='store_true')
  parser.add_argument('--fused-qkv',action='store_true')
  parser.add_argument('--cpu-norm',action='store_true')
  parser.add_argument('--context',type=int,default=512)
  parser.add_argument('--tokens',type=int,default=32)
  parser.add_argument('--warmups',type=int,default=2)
  parser.add_argument('--runs',type=int,default=3)
  parser.add_argument('--stock-reference',type=Path)
  parser.add_argument('--report',type=Path,required=True)
  args = parser.parse_args()
  prompt = [int(value) for value in args.input.read_text().split()]
  if not prompt or args.tokens<2 or args.runs<1 or args.warmups<1 or len(prompt)+args.tokens>args.context:
    parser.error('Need prompt, >=2 output tokens, warmup and measured runs, within context')
  expected = stock_ids(args.stock_reference,args.tokens) if args.stock_reference else None
  os.environ['DEV'] = args.device
  from tinygrad import Device, Tensor
  from tinygrad.llm.model import Transformer
  from tinygrad.llm.kernels.rockchip import configure
  from tinygrad.llm.kernels import rockchip_cpu, rockchip_replay, rockchip_qkv  # noqa: F401 -- load measured sources before hashing

  root = Path(__file__).resolve().parents[2]
  sources = [Path(__file__),*(root/name for name in [
    'tinygrad/runtime/ops_rockchip.py','tinygrad/llm/kernels/rockchip.py','tinygrad/llm/kernels/rockchip_cpu.py',
    'tinygrad/llm/kernels/rockchip_replay.py','tinygrad/llm/kernels/rockchip_qkv.py','tinygrad/llm/model.py'])]
  with args.checkpoint.open('rb') as file: checkpoint_hash = hashlib.file_digest(file,'sha256').hexdigest()
  report = {'complete':False,'device':args.device,'context':args.context,'input_ids':prompt,
            'checkpoint':str(args.checkpoint.resolve()),'checkpoint_sha256':checkpoint_hash,
            'precision':'FP16 prepared weights and NPU operands; FP32 accumulation and host arithmetic',
            'sampling':'temperature=0; raw IDs; no template; EOS ignored; empty KV history each request',
            'prefill':args.prefill,'decode':args.decode,'warmups':args.warmups,'runs':args.runs,
            'split_down':args.split_down,'fused_qkv':args.fused_qkv,'cpu_norm':args.cpu_norm,
            'cpu_affinity':sorted(os.sched_getaffinity(0)),'initial_clocks':clocks(),'trials':[],
            'source_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}}
  def save(): args.report.write_text(json.dumps(report,indent=2)+'\n')
  save()
  begin = time.perf_counter()
  model,_ = Transformer.from_gguf(args.checkpoint,max_context=args.context,realize=True)
  report['load_seconds'] = time.perf_counter()-begin
  jits = {'prefill':model.greedy_prefill_jit,'decode':model.greedy_rollout_jit}
  begin = time.perf_counter()
  report['placement'] = configure(model,prefill=args.prefill,decode=args.decode,
                                 tile_columns=args.tile_columns,fuse_projections=args.fuse_projections,
                                 cpu_attention=args.cpu_attention,native_replay=args.native_replay,
                                 fused_ffn=args.fused_ffn,split_down=args.split_down,fused_qkv=args.fused_qkv,cpu_norm=args.cpu_norm)
  report['prepare_seconds'] = time.perf_counter()-begin
  npu = Device['ROCKCHIP'] if args.prefill!='off' or args.decode!='off' else None
  print(json.dumps({'event':'ready','load_seconds':report['load_seconds'],
                    'prepare_seconds':report['prepare_seconds'],'placement':report['placement']}),flush=True)
  save()
  try:
    for index in range(args.warmups+args.runs):
      model._cached_tokens = []
      for block in model.blk:
        if hasattr(block,'cache_kv'): block.cache_kv.assign(Tensor.zeros_like(block.cache_kv)).realize()
      Tensor.manual_seed(0)
      row = {'index':index,'warmup':index<args.warmups,'clocks_before':clocks()}
      submits_before = npu.submit_count if npu else 0
      ids, stamps = [],[]
      observe('begin',index)
      begin = time.perf_counter()
      for token in itertools.islice(model.generate(prompt.copy(),chunk_size=len(prompt),temperature=0),args.tokens):
        stamps.append(time.perf_counter())
        ids.append(token)
        if len(ids)==1:
          first_submits = npu.submit_count if npu else 0
          observe('first',index)
          print(json.dumps({'event':'first_token','index':index,'id':token,'first_token_ms':(stamps[0]-begin)*1000}),flush=True)
      if len(ids)!=args.tokens: raise RuntimeError('Incomplete generated sequence')
      observe('end',index)
      row.update(generated_ids=ids,first_token_ms=(stamps[0]-begin)*1000,
                 prefill_tps=len(prompt)/(stamps[0]-begin),decode_tps=(len(ids)-1)/(stamps[-1]-stamps[0]),
                 prefill_submits=first_submits-submits_before,
                 decode_submits=(npu.submit_count if npu else 0)-first_submits,
                 clocks_after=clocks(),matches_stock=ids==expected if expected is not None else None)
      report['trials'].append(row)
      report['captured_calls'] = {phase:dict(Counter(f'{call.body.op.name}:{call.device}' for call in jit.captured.linear.src))
                                  for phase,jit in jits.items() if jit.captured is not None}
      report['native_execution'] = {phase:{'runs':getattr(jit.captured,'native_runs',0),'reason':getattr(jit.captured,'reason',None),
        'direct_inputs':len(jit.captured.native.alias_copies) if getattr(jit.captured,'native',None) is not None else 0,
        'profile':[{'name':k,'ms':v/1e6,'calls':jit.captured.native.profile_counts[k]}
                   for k,v in jit.captured.native.profile_ns.most_common()] if getattr(jit.captured,'native',None) is not None else []}
                                   for phase,jit in jits.items() if jit.captured is not None}
      save()
      print(json.dumps({'event':'run',**row}),flush=True)
      if expected is not None and ids!=expected: raise AssertionError(f'IDs differ from stock: {ids} != {expected}')
    rows = [row for row in report['trials'] if not row['warmup']]
    if args.native_replay:
      assert all(value['runs']>0 for value in report['native_execution'].values()),report['native_execution']
    report.update(complete=True,median_decode_tps=statistics.median(row['decode_tps'] for row in rows),
                  median_first_token_ms=statistics.median(row['first_token_ms'] for row in rows))
    print(json.dumps({key:report[key] for key in ['complete','median_decode_tps','median_first_token_ms']}),flush=True)
  except BaseException as exc:
    report['error'] = f'{type(exc).__name__}: {exc}'
    raise
  finally: save()
  return model,jits


if __name__=='__main__': main()
