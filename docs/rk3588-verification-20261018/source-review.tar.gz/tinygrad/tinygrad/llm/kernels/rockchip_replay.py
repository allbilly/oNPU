"""Native replay of prepared CPU/Rockchip inference calls, with guarded fallback."""
from __future__ import annotations
import ctypes, time
from collections import Counter
from dataclasses import replace
from typing import Any, cast
from tinygrad import Device
from tinygrad.device import Buffer, BufferStorage, TinyELF
from tinygrad.dtype import AddrSpace, dtypes
from tinygrad.engine.jit import CapturedJit, _copy_input
from tinygrad.engine.realize import _resolve, estimate_uop, get_runtime, get_call_arg_uops, get_call_outs_ins
from tinygrad.helpers import DEBUG, PROFILE, GlobalCounters, getenv, unwrap
from tinygrad.renderer import Estimates
from tinygrad.renderer.cstyle import ClangRenderer
from tinygrad.runtime.ops_cpu import CPUProgram
from tinygrad.runtime.ops_rockchip import RockchipBuffer, RockchipDevice, RockchipProgram, _FINITE_HALF_SOURCE
from tinygrad.runtime.autogen import rockchip as rk
from tinygrad.uop.ops import Ops, UOp, sym_infer


class UnsupportedReplay(Exception): pass


class NativeReplay:
  def __init__(self, linear:UOp, inputs:list[UOp], values:dict[str,int]):
    self.linear, self.inputs = linear, tuple(inputs)
    self.roots = [cast(Buffer,u.buffer).ensure_allocated() for u in inputs]
    if any(buf.device!='CPU' for buf in self.roots): raise UnsupportedReplay('non-CPU inputs')
    self.input_sizes = [buf.nbytes for buf in self.roots]
    self.variables = sorted(values)
    self.kept:list[Any] = []
    self.guards:dict[Buffer,BufferStorage] = {}
    self.writes:dict[int,Any] = {}
    self.write_counts:Counter[int] = Counter()
    self.weight_guards:dict[int,tuple[Any,int]] = {}
    self.plans:list[tuple[Any,tuple]] = []
    self.mutated:set[int] = set()
    self.calls = [call.without_after for call in linear.src]
    if not any(call.op is Ops.CALL and call.device=='ROCKCHIP' for call in self.calls): raise UnsupportedReplay('no NPU work')
    self.dev = cast(RockchipDevice,Device['ROCKCHIP'])
    self.libc = ctypes.CDLL(None)
    ioctl = unwrap(ctypes.cast(self.libc.ioctl,ctypes.c_void_p).value)
    memcpy = unwrap(ctypes.cast(self.libc.memmove,ctypes.c_void_p).value)
    self.ioctl = f'((int(*)(int,unsigned long,...)){ioctl}ULL)'
    self.memcpy = f'((void*(*)(void*,const void*,unsigned long)){memcpy}ULL)'
    self.statements:list[str] = []
    self.aliases,self.alias_copies = self.input_aliases()
    self.profiling = bool(getenv('ONPU_REPLAY_PROFILE',0))
    self.profile_ns:Counter[str] = Counter()
    self.profile_counts:Counter[str] = Counter()
    self.labels:list[str] = []
    self.estimates = Estimates()
    self.submits = 0
    for index,call in enumerate(self.calls):
      if call.op is not Ops.CALL: raise UnsupportedReplay('non-call graph entry')
      self.estimates += estimate_uop(call)
      start = len(self.statements)
      if call.body.op is Ops.STORE: self.copy(call,index)
      elif call.body.op is Ops.PROGRAM: self.kernel(call,index)
      else: raise UnsupportedReplay('unsupported call body')
      label = (f'{call.device}:{call.body.src[0].arg.function_name}' if call.body.op is Ops.PROGRAM else
               f'COPY:{call.src[2].device}->{call.src[1].device}')
      self.labels.append(label)
      if self.profiling:
        self.statements[start:] = ['{U64 begin=now();']+self.statements[start:]+[f'stats[{index+2}]=now()-begin;}}']
    if not self.submits: raise UnsupportedReplay('no prepared NPU work')
    if self.mutated.intersection(self.weight_guards): raise UnsupportedReplay('mutable matrix weights')
    self.estimates = self.estimates.simplify()
    sym_infer(self.estimates.ops,values)
    sym_infer(self.estimates.mem,values)
    params = [*(f'void *input{i}' for i in range(len(inputs))),*(f'long long value{i}' for i in range(len(self.variables))),
              'unsigned long long *stats']
    clock = unwrap(ctypes.cast(self.libc.clock_gettime,ctypes.c_void_p).value)
    timing = (f'static inline U64 now(void){{long ts[2];((int(*)(int,void*)){clock}ULL)({time.CLOCK_MONOTONIC},ts);'
              'return (U64)ts[0]*1000000000ULL+ts[1];}') if self.profiling else ''
    statements = '\n'.join(self.statements)
    source = '''typedef unsigned int U32;typedef unsigned long long U64;
    struct Sync {U32 flags,reserved;U64 object,offset,size;} __attribute__((packed));
    struct Submit {U32 flags,timeout,start,number,counter;int priority;U64 object,regcfg,base,user;
                   U32 mask;int fence;U32 subcores[10];} __attribute__((packed));
    '''+_FINITE_HALF_SOURCE+timing+f'int replay({",".join(params)}) {{ stats[0]=stats[1]=0;\n'+statements+'\nreturn 0;}'
    cpu = Device['CPU']
    renderer = ClangRenderer(replace(cpu.renderer.target,renderer='CLANG'))
    self.program = cast(Any,cpu.runtime(TinyELF(renderer.compiler.compile_cached(source),'replay',renderer.target,())))
    self.program.fxn.restype = ctypes.c_int
    self.source = source

  def buffer(self, node:UOp) -> tuple[Buffer,Any,str]:
    # Symbolic views require their own pointer expression; leave them on the ordinary executor.
    if any(u.is_variable for u in node.toposort()): raise UnsupportedReplay('symbolic buffer view')
    buf = _resolve(node,self.inputs).buffer
    if not isinstance(buf,Buffer) or buf.device not in ('CPU','ROCKCHIP','PYTHON','NPY'):
      raise UnsupportedReplay('unsupported buffer device')
    buf.ensure_allocated()
    raw = buf.get_buf(buf.device)
    if isinstance(raw,RockchipBuffer): address = raw.addr
    elif isinstance(raw,int): address = raw
    else: raise UnsupportedReplay('unsupported raw buffer')
    self.kept.append(buf)
    for i,root in enumerate(self.roots):
      if buf.base is root.base: return buf,raw,f'((char*)input{i}+{buf.offset-root.offset})'
    self.guards[buf.base] = unwrap(buf.base._storage)
    return buf,raw,f'((void*){address}ULL)'

  def sync(self, raw:RockchipBuffer, flag:int, index:int) -> str:
    request = (3<<30)|(ctypes.sizeof(rk.struct_rknpu_mem_sync)<<16)|(ord('d')<<8)|0x45
    return (f'{{struct Sync sync={{{flag},0,{raw.meta.obj_addr}ULL,{raw.dma-int(raw.meta.dma_addr)}ULL,{raw.size}ULL}};'
            f'if({self.ioctl}({self.dev.fd.fd},{request}UL,&sync)!=0)return {2000000+index};}}')

  def input_aliases(self) -> tuple[dict,set[int]]:
    """Redirect sole-use scratch pack outputs into the following NPU upload mapping."""
    events = []
    copies = []
    for i,call in enumerate(self.calls):
      if call.op is not Ops.CALL or call.body.op not in (Ops.PROGRAM,Ops.STORE): continue
      outs,ins = get_call_outs_ins(call)
      slots = (range(2) if call.body.op is Ops.STORE else
               [p.arg.slot for p in call.body.kernel_params if p.addrspace is not AddrSpace.ALU])
      buffers = {}
      for slot in slots:
        node = call.src[1+slot]
        buf,raw,expr = self.buffer(node)
        key = (buf.base,buf.offset,buf.nbytes)
        event = (i,key,slot in outs,slot in ins,buf.device,node,raw,expr)
        events.append(event)
        buffers[slot] = event
      if call.body.op is Ops.STORE and 0 in buffers and 1 in buffers: copies.append((buffers[0],buffers[1]))
    aliases,omitted = {},set()
    def overlap(a,b): return a[0] is b[0] and a[1]<b[1]+b[2] and b[1]<a[1]+a[2]
    for dst,src in copies:
      i,key = src[:2]
      if (not isinstance(dst[6],RockchipBuffer) or src[4]!='CPU' or key[2]!=dst[1][2]
          or not any(u.op is Ops.BUFFER and u.tag=='scratch' for u in src[5].toposort())): continue
      prior = [e for e in events if e[0]<i and overlap(e[1],key)]
      if not prior: continue
      writer = prior[-1]
      if (writer[1]!=key or not writer[2] or writer[3] or writer[4]!='CPU' or self.calls[writer[0]].device!='CPU'
          or writer[5].dtype is not dtypes.half): continue
      if any(e[0]==writer[0] and e is not writer and overlap(e[1],key) for e in events): continue
      future = [e for e in events if e[0]>i and overlap(e[1],key)]
      if future and any(e[3] for e in future if e[0]==future[0][0]): continue
      if any(writer[0]<e[0]<i and isinstance(e[6],RockchipBuffer) and e[6].meta is dst[6].meta for e in events): continue
      aliases[(writer[0],key)] = dst[7]
      omitted.add(i)
    return aliases,omitted

  def copy(self, call:UOp, index:int):
    nodes = get_call_arg_uops(call)
    if len(nodes)!=2: raise UnsupportedReplay('copy signature')
    dst,d,dp = self.buffer(nodes[0])
    src,s,sp = self.buffer(nodes[1])
    if dst.nbytes!=src.nbytes: raise UnsupportedReplay('copy sizes')
    if isinstance(s,RockchipBuffer): self.statements.append(self.sync(s,rk.RKNPU_MEM_SYNC_FROM_DEVICE,index))
    if index not in self.alias_copies: self.statements.append(f'{self.memcpy}({dp},{sp},{dst.nbytes}UL);')
    if isinstance(d,RockchipBuffer):
      self.statements.append(self.sync(d,rk.RKNPU_MEM_SYNC_TO_DEVICE,index))
      self.writes[id(d.meta)] = d.meta
      self.write_counts[id(d.meta)] += 1
      self.mutated.add(id(d.meta))

  def scalar(self, param:UOp, call:UOp) -> tuple[str,str]:
    if not (dtypes.is_int(param.dtype) or param.dtype is dtypes.bool): raise UnsupportedReplay('noninteger scalar')
    typ = ('unsigned ' if dtypes.is_unsigned(param.dtype) or param.dtype is dtypes.bool else '')+'long long'
    bound = {u.expr:u.arg.val for u in call.src[1:] if u.is_bound_var}
    if param.is_variable and param.expr not in bound:
      if param.expr not in self.variables: raise UnsupportedReplay('unknown scalar variable')
      return typ,f'value{self.variables.index(param.expr)}'
    value = bound[param.expr] if param.is_variable else _resolve(call.src[1+param.arg.slot],self.inputs).val
    return typ,f'(({typ}){int(value)})'

  def kernel(self, call:UOp, index:int):
    device = call.device
    if device not in ('CPU','ROCKCHIP'): raise UnsupportedReplay('kernel device')
    runtime = get_runtime(device,call.body)
    self.kept.append(runtime)
    raw,expressions,types = [],[],[]
    for param in call.body.kernel_params:
      if param.addrspace is AddrSpace.ALU:
        typ,value = self.scalar(param,call)
        types.append(typ)
        expressions.append(value)
      else:
        buf,buffer,value = self.buffer(call.src[1+param.arg.slot])
        value = self.aliases.get((index,(buf.base,buf.offset,buf.nbytes)),value)
        raw.append(buffer)
        types.append('void*')
        expressions.append(value)
    if isinstance(runtime,CPUProgram):
      if any(isinstance(buf,RockchipBuffer) for buf in raw): raise UnsupportedReplay('CPU kernel touches NPU mapping')
      if runtime.lvp or runtime.dev.remote is not None: raise UnsupportedReplay('CPU execution mode')
      address = unwrap(ctypes.cast(runtime.fxn,ctypes.c_void_p).value)
      self.statements.append(f'((void(*)({",".join(types)})){address}ULL)({",".join(expressions)});')
      return
    if not isinstance(runtime,RockchipProgram) or len(raw)!=3 or not all(isinstance(buf,RockchipBuffer) for buf in raw):
      raise UnsupportedReplay('NPU kernel signature')
    key = tuple((id(buf.meta),buf.addr,buf.size) for buf in raw)
    if (plan:=runtime.bindings.get(key)) is None: raise UnsupportedReplay('NPU binding not prepared')
    out,lhs,rhs = raw
    if out.meta.cpu_clean_version!=out.meta.version: raise UnsupportedReplay('dirty NPU output mapping')
    if plan.weight_version!=(rhs.meta.obj_addr,rhs.meta.version): raise UnsupportedReplay('unverified matrix weights')
    self.weight_guards[id(rhs.meta)] = rhs.meta,rhs.meta.version
    self.mutated.add(id(out.meta))
    self.kept.append(plan)
    self.plans.append((plan,plan.bufs))
    self.statements.append(f'if(!all_finite_half((const unsigned short*){lhs.addr+plan.lhs_offset}ULL,{plan.m*plan.k}UL))'
      f'return {1000000+index};')
    # The warm replay cleaned initial output pages. Subsequent CPU writes are
    # COPY destinations followed immediately by TO_DEVICE; NPU writes need FROM_DEVICE only.
    # Prepared task/command descriptors are immutable and were flushed by prepare().
    subcores = [value for pair in (*plan.subcores,*((0,0),)*(5-len(plan.subcores))) for value in pair]
    fields = [5,6000,0,plan.tasks,0,0,f'{plan.task.meta.obj_addr}ULL',0,0,0,plan.core_mask,-1]
    request = (3<<30)|(ctypes.sizeof(rk.struct_rknpu_submit)<<16)|(ord('d')<<8)|0x41
    self.statements.append('{struct Submit submit={'+','.join(map(str,fields))+',{'+','.join(map(str,subcores))+'}};'
      f'if({self.ioctl}({self.dev.fd.fd},{request}UL,&submit)!=0)return {2000000+index};'
      f'stats[0]++;stats[1]+={plan.tasks};}}')
    self.submits += 1

  def valid(self, inputs:list[UOp]) -> bool:
    return (len(inputs)==len(self.roots) and all(isinstance(u.buffer,Buffer) and u.buffer.device=='CPU'
      and u.buffer.nbytes==size for u,size in zip(inputs,self.input_sizes))
      and all(buf._storage is storage for buf,storage in self.guards.items())
      and all(meta.version==version for meta,version in self.weight_guards.values())
      and all(plan.bufs[0].meta.cpu_clean_version==plan.bufs[0].meta.version for plan,_ in self.plans if plan.bufs)
      and all(plan.owned and plan.bufs==buffers for plan,buffers in self.plans))

  def __call__(self, inputs:list[UOp], values:dict[str,int]):
    ops,mem = sym_infer(self.estimates.ops,values),sym_infer(self.estimates.mem,values)
    pointers = [ctypes.c_void_p(cast(Buffer,u.buffer).ensure_allocated().get_buf('CPU')) for u in inputs]
    scalars = [ctypes.c_int64(values[name]) for name in self.variables]
    stats = (ctypes.c_uint64*(2+len(self.calls) if self.profiling else 2))()
    with self.dev.lock:
      self.dev.check_healthy()
      result = self.program.fxn(*pointers,*scalars,stats)
      self.dev.submit_count += stats[0]
      self.dev.task_count += stats[1]
      if result>=2000000:
        self.dev.poisoned = True
        raise RuntimeError(f'NPU native replay submission failed at call {result-2000000}')
      if result: raise ValueError(f'NPU native replay requires finite activations at call {result-1000000}')
      for key,meta in self.writes.items():
        meta.version += self.write_counts[key]
        meta.cpu_clean_version = meta.version
    GlobalCounters.kernel_count += len(self.calls)
    GlobalCounters.global_ops += ops
    GlobalCounters.global_mem += mem
    if self.profiling:
      for i,label in enumerate(self.labels):
        self.profile_ns[label] += stats[i+2]
        self.profile_counts[label] += 1


class RockchipCapturedJit(CapturedJit):
  def __init__(self, captured:CapturedJit):
    super().__init__(captured.ret,captured._linear,captured.expected_names,captured.expected_input_info)
    self.native:NativeReplay|None = None
    self.warmed = False
    self.reason:str|None = None
    self.native_runs = 0

  def __reduce__(self): return CapturedJit,(self.ret,self._linear,self.expected_names,self.expected_input_info)

  def free_intermediates(self):
    self.native,self.warmed,self.reason = None,False,None
    super().free_intermediates()

  def __call__(self, input_uops:list[UOp], var_vals:dict[str,int]):
    if DEBUG>=2 or PROFILE or self.reason is not None: return super().__call__(input_uops,var_vals)
    if not self.warmed:
      result = super().__call__(input_uops,var_vals)
      self.warmed = True
      return result
    concrete = [_copy_input(u) if u in self._jit_bufs else u for u in input_uops]
    if self.native is not None and not self.native.valid(concrete): self.native = None
    if self.native is None:
      try: self.native = NativeReplay(self.linear,concrete,var_vals)
      except (UnsupportedReplay,KeyError,AssertionError) as exc:
        self.reason = str(exc)
        return super().__call__(input_uops,var_vals)
    self.native(concrete,var_vals)
    self.native_runs += 1
    for tensor,uop,values in self._symbolic_ret:
      tensor.uop = uop.substitute({v:v.bind(var_vals.get(v.expr,i)) for v,i in values.items()},walk=True)
    return self.ret
