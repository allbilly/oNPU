"""Explicit FP16 Rockchip matrix kernels; surrounding operations retain their device."""
from __future__ import annotations
import functools, math, statistics, struct, time
from dataclasses import replace
from tinygrad import Device, Tensor, TinyJit, dtypes, nn
from tinygrad.engine.jit import _TinyJit
from tinygrad.helpers import Target, round_up
from tinygrad.uop.ops import KernelInfo, Ops, ProgramInfo, UOp, resolve


@functools.cache
def _matmul(out:UOp, lhs:UOp, rhs:UOp, m:int, n:int, k:int, cores:int, column_offset:int, row_offset:int=0,
            split_k:bool=False) -> UOp:
  sink = UOp.sink(out,lhs,rhs,arg=KernelInfo(f'rockchip_matmul_{m}_{n}_{k}'))
  info = replace(ProgramInfo.from_sink(sink,Target('ROCKCHIP')),outs=(0,),ins=(1,2))
  return UOp(Ops.PROGRAM,arg=info,src=(sink,UOp(Ops.LINEAR,src=(out,lhs,rhs)),
             UOp(Ops.SOURCE,arg=f'Rockchip FP16 {m}x{k}x{n} columns+{column_offset}'),
             UOp(Ops.BINARY,arg=struct.pack('<7I',m,n,k,cores,column_offset*k*2,row_offset*k*2,int(split_k)))))


def pack_weight(weight:Tensor) -> Tensor:
  n,k = weight.shape
  if not isinstance(n,int) or not isinstance(k,int) or not 0 < k <= 4096 or not 0 < n <= 24576:
    raise ValueError('Rockchip weight tiles require static K<=4096 and N<=24576')
  n,k = round_up(n,32),round_up(k,32)
  return weight.half().pad(((0,n-weight.shape[0]),(0,k-weight.shape[1]))).reshape(n//16,16,k//32,32).permute(0,2,1,3).contiguous().to('ROCKCHIP')


def pack_split_weight(weight:Tensor) -> Tensor:
  n,k = weight.shape
  if not isinstance(n,int) or not isinstance(k,int) or k%96 or not 0<k<=4096 or not 0<n<=4096:
    raise ValueError('Unsupported three-part Rockchip weight')
  n = round_up(n,32)
  return weight.half().pad(((0,n-weight.shape[0]),(0,0))).reshape(n//16,16,3,k//96,32).permute(
    2,0,3,1,4).contiguous().to('ROCKCHIP')


def packed_matmul(x:Tensor, weight:Tensor, columns:int, cores:int=3, column_offset:int=0, raw_output:bool=False) -> Tensor:
  """Return FP32 accumulation in the input device, with no host numeric fallback."""
  if cores not in (1,3): raise ValueError('Rockchip supports one or three cores')
  if x.ndim!=2 or weight.ndim!=4 or weight.shape[2:]!=(16,32) or weight.dtype is not dtypes.half or weight.device!='ROCKCHIP':
    raise ValueError('Rockchip matmul requires a matrix and an explicitly packed FP16 NPU weight')
  m,original_k = x.shape
  capacity,k = weight.shape[0]*16,weight.shape[1]*32
  n = round_up(columns,32)
  if (not isinstance(m,int) or not 1 <= m <= min(64,65536//k) or not 0 < original_k <= k or columns<1
      or column_offset<0 or column_offset%32 or column_offset+n>capacity or n>(8192 if m==1 else 4096)*cores):
    raise ValueError('Rockchip input tile exceeds the tested CBUF bounds')
  lhs = x.half().pad(((0,0),(0,k-original_k))).reshape(m,k//8,8).permute(1,0,2).contiguous().to('ROCKCHIP')
  out = Tensor.empty(n//4,m,4,device='ROCKCHIP',dtype=dtypes.float)
  out = out.custom_kernel(lhs,weight,fxn=lambda o,a,w:_matmul(o,a,w,m,n,k,cores,column_offset))[0]
  if raw_output: return out.to(x.device).flatten()
  return out.to(x.device).permute(1,0,2).reshape(m,n)[:,:columns]


def packed_activation_matmul(lhs:Tensor, weight:Tensor, rows:int, columns:int, row_offset:int=0, column_offset:int=0,
                             split_k:bool=False, raw_output:bool=False) -> Tensor:
  """Consume one tile from concatenated (K/8,M,8) input payloads, returning CPU FP32."""
  if lhs.device!='ROCKCHIP' or lhs.dtype is not dtypes.half or lhs.ndim!=1 or weight.device!='ROCKCHIP':
    raise ValueError('Invalid packed Rockchip activation')
  k,n = (weight.shape[2]*96 if split_k else weight.shape[1]*32),round_up(columns,32)
  capacity = weight.shape[1 if split_k else 0]*16
  if (not 1<=rows<=min(64,65536//(k//3 if split_k else k)) or row_offset<0 or column_offset<0 or column_offset%32
      or (row_offset+rows)*k>lhs.numel() or column_offset+n>capacity or n>(4096 if split_k else 24576 if rows==1 else 12288)):
    raise ValueError('Packed Rockchip activation exceeds its tile bounds')
  out = Tensor.empty(*((3,) if split_k else ()),n//4,rows,4,device='ROCKCHIP',dtype=dtypes.float)
  out = out.custom_kernel(lhs,weight,fxn=lambda o,a,w:_matmul(o,a,w,rows,n,k,3,column_offset,row_offset,split_k))[0]
  if raw_output: return out.to('CPU')
  if split_k: return out.to('CPU').permute(0,2,1,3).reshape(3,rows,n).sum(0)[:,:columns]
  return out.to('CPU').permute(1,0,2).reshape(rows,n)[:,:columns]


class RockchipLinear:
  """An inference-only Linear with independent prefill and decode placement.

  Auto decisions include host/device transfers and use the original layer as the
  timing and numerical reference. Model weights are immutable after preparation.
  """
  def __init__(self, source:nn.Linear, prefill:str, decode:str, tile_columns:int=4096):
    if prefill not in ('off','auto','on') or decode not in ('off','auto','on'): raise ValueError('Invalid NPU placement')
    if not 32<=tile_columns<=24576 or tile_columns%32: raise ValueError('Invalid NPU column tile')
    self.source, self.prefill, self.decode = source, prefill, decode
    self.tile_columns = tile_columns
    self.weight, self.bias = source.weight, source.bias
    self.phase:str|None = None
    columns, depth = self.weight.shape
    assert isinstance(columns,int) and isinstance(depth,int)
    self.columns, self.depth = columns, depth
    self.packed:list[Tensor] = []

  def prepare(self):
    if not self.packed:
      self.packed = [pack_weight(self.weight[start:start+self.tile_columns]).realize()
                     for start in range(0,self.columns,self.tile_columns)]

  def npu(self, x:Tensor) -> Tensor:
    from tinygrad.llm.kernels.rockchip_cpu import unpack_tiles
    shape = x.shape
    dense = x.pad_to(x.max_shape).half().reshape(-1,x.shape[-1])
    assert isinstance(self.depth,int) and isinstance(self.columns,int)
    row_tile = min(64,65536//round_up(self.depth,32))
    raw = x.device=='CPU' and dense.shape[0]>1 and len(self.packed)==1 and round_up(self.columns,32)<=12288 \
      and math.ceil(dense.shape[0]/row_tile)<=64
    rows = []
    for start in range(0,dense.shape[0],row_tile):
      part = dense[start:start+row_tile]
      if raw:
        rows.append(packed_matmul(part,self.packed[0],self.columns,raw_output=True).reshape(round_up(self.columns,32)//4,part.shape[0],4))
        continue
      columns = []
      for i,w in enumerate(self.packed):
        width = min(self.tile_columns,self.columns-i*self.tile_columns)
        # Three cores share the packed input and write disjoint output columns in both phases.
        for col in range(0,width,24576 if part.shape[0]==1 else 12288):
          end = min(width,col+(24576 if part.shape[0]==1 else 12288))
          columns.append(packed_matmul(part,w,end-col,column_offset=col))
      rows.append(Tensor.cat(*columns,dim=1))
    out = (unpack_tiles(rows)[:,:self.columns] if raw else Tensor.cat(*rows,dim=0)).reshape(*x.max_shape[:-1],self.weight.shape[0])
    out = out.shrink(tuple((0,s) for s in (*shape[:-1],self.weight.shape[0]))).cast(x.dtype)
    return out if self.bias is None else out+self.bias

  def __call__(self, x:Tensor) -> Tensor:
    phase = self.phase or ('decode' if resolve(math.prod(x.shape[:-1])==1,default=False) else 'prefill')
    mode = getattr(self,phase)
    return self.npu(x) if mode=='on' else self.source(x)


class RockchipProjections:
  """One shared-input projection, retaining each original output and phase policy."""
  def __init__(self, layers:tuple[RockchipLinear,...], tile_columns:int):
    self.layers = layers
    source = nn.Linear.__new__(nn.Linear)
    source.weight = Tensor.cat(*(layer.weight for layer in layers),dim=0)
    biases = [layer.bias for layer in layers if layer.bias is not None]
    if biases and len(biases)!=len(layers): raise ValueError('Projection biases must share one layout')
    source.bias = Tensor.cat(*biases,dim=0) if biases else None
    self.joint = RockchipLinear(source,'on','on',tile_columns)
    self.joint.prepare()

  def __call__(self, x:Tensor) -> tuple[Tensor,...]:
    phase = self.layers[0].phase or ('decode' if resolve(math.prod(x.shape[:-1])==1,default=False) else 'prefill')
    if not all(getattr(layer,phase)=='on' for layer in self.layers): return tuple(layer(x) for layer in self.layers)
    out = self.joint.npu(x)
    offset, parts = 0,[]
    for layer in self.layers:
      parts.append(out[...,offset:offset+layer.columns])
      offset += layer.columns
    return tuple(parts)


class RockchipRMSNorm:
  def __init__(self, source:nn.RMSNorm): self.source,self.weight,self.eps = source,source.weight,source.eps

  def __call__(self, x:Tensor) -> Tensor:
    if (x.device=='CPU' and x.dtype is dtypes.float and math.prod(x.max_shape[:-1])>=16
        and self.weight is not None and self.weight.device=='CPU' and self.weight.dtype in (dtypes.float,dtypes.half)
        and 4<=x.max_shape[-1]<=8192 and x.max_shape[-1]%4==0):
      from tinygrad.llm.kernels.rockchip_cpu import rms_norm
      return rms_norm(x,self.weight,self.eps)
    return self.source(x)


class RockchipPreparedQKV:
  def __init__(self, projections:RockchipProjections, heads:int, qnorm:Tensor, knorm:Tensor, eps:float):
    self.projections,self.heads,self.qnorm,self.knorm,self.eps = projections,heads,qnorm,knorm,eps

  def enabled(self, x:Tensor) -> bool:
    phase = self.projections.layers[0].phase or ('decode' if resolve(math.prod(x.shape[:-1])==1,default=False) else 'prefill')
    return phase=='prefill' and x.device=='CPU' and x.dtype is dtypes.float and x.ndim==3 and x.shape[0]==1 and x.max_shape[1]>=16 \
      and all(layer.prefill=='on' for layer in self.projections.layers)

  def __call__(self, x:Tensor, start:int|UOp, cache:Tensor, freqs:Tensor) -> tuple[Tensor,Tensor]:
    from tinygrad.llm.kernels.rockchip_qkv import prepare_qkv
    return prepare_qkv(self.projections.joint.npu(x),cache,self.qnorm,self.knorm,freqs,start,self.heads,self.eps)


class RockchipFeedForward:
  """Fused FP32 SwiGLU and raw input packing for a CPU/NPU dense FFN."""
  def __init__(self, projections:RockchipProjections, down:RockchipLinear, split_down:bool=False):
    self.projections,self.down = projections,down
    self.split_weight = pack_split_weight(down.weight).realize() if split_down and down.depth%96==0 and down.columns<=4096 else None

  def enabled(self, x:Tensor) -> bool:
    phase = self.down.phase or ('decode' if resolve(math.prod(x.shape[:-1])==1,default=False) else 'prefill')
    return x.device=='CPU' and x.dtype is dtypes.float and all(
      getattr(layer,phase)=='on' for layer in (*self.projections.layers,self.down))

  def __call__(self, x:Tensor) -> Tensor:
    from tinygrad.llm.kernels.rockchip_cpu import swiglu_pack, swiglu_pack_tiles
    joint = self.projections.joint
    input_tile = min(64,65536//round_up(joint.depth,32))
    depth = self.down.depth
    split = self.split_weight is not None
    row_tile = min(64,65536//(depth//3 if split else depth))
    if len(joint.packed)==1 and joint.columns%32==0 and joint.bias is None:
      dense = x.pad_to(x.max_shape).reshape(-1,x.shape[-1])
      parts = [packed_matmul(dense[start:start+input_tile],joint.packed[0],joint.columns,raw_output=True)
               for start in range(0,dense.shape[0],input_tile)]
      packed = swiglu_pack_tiles(parts,depth,row_tile,split)
    else:
      projected = joint.npu(x)
      packed = swiglu_pack(projected,depth,row_tile,split_k=split)
    packed = packed.to('ROCKCHIP')
    rows = []
    count = math.prod(x.max_shape[:-1])
    for start in range(0,count,row_tile):
      m = min(row_tile,count-start)
      if self.split_weight is not None:
        rows.append(packed_activation_matmul(packed,self.split_weight,m,self.down.columns,start,split_k=True,raw_output=True))
        continue
      columns = []
      for i,weight in enumerate(self.down.packed):
        width = min(self.down.tile_columns,self.down.columns-i*self.down.tile_columns)
        limit = 24576 if m==1 else 12288
        for col in range(0,width,limit):
          columns.append(packed_activation_matmul(packed,weight,m,min(limit,width-col),start,col))
      rows.append(Tensor.cat(*columns,dim=1))
    if self.split_weight is not None:
      from tinygrad.llm.kernels.rockchip_cpu import unpack_tiles
      out = unpack_tiles(rows,split=True)[:,:self.down.columns]
    else: out = Tensor.cat(*rows,dim=0)
    out = out.reshape(*x.max_shape[:-1],self.down.columns)
    out = out.shrink(tuple((0,s) for s in (*x.shape[:-1],self.down.columns))).cast(x.dtype)
    return out if self.down.bias is None else out+self.down.bias


def configure(model, prefill:str='off', decode:str='off', tile_columns:int=4096, fuse_projections:bool=False,
              cpu_attention:bool=False, native_replay:bool=False, fused_ffn:bool=False, split_down:bool=False, fused_qkv:bool=False,
              cpu_norm:bool=False) -> dict:
  """Replace only supported dense Linears; return measured placement decisions."""
  layers:list[RockchipLinear] = []
  seen:set[int] = set()
  def visit(obj):
    if id(obj) in seen or isinstance(obj,Tensor): return
    seen.add(id(obj))
    items = list(enumerate(obj)) if isinstance(obj,list) else list(obj.items()) if isinstance(obj,dict) else list(vars(obj).items())
    for key,value in items:
      if isinstance(value,nn.Linear):
        if len(value.weight.shape)!=2 or value.weight.shape[1]>4096: continue
        layer = RockchipLinear(value,prefill,decode,tile_columns)
        if isinstance(obj,(dict,list)): obj[key] = layer
        else: setattr(obj,str(key),layer)
        layers.append(layer)
      elif isinstance(value,(list,dict)) or hasattr(value,'__dict__') and not isinstance(value,(type,Tensor)): visit(value)
  visit(model)
  decisions:dict[tuple,dict] = {}
  for layer in layers:
    if prefill==decode=='off': continue
    layer.prepare()
    for phase,rows in [('decode',1),('prefill',32)]:
      mode = getattr(layer,phase)
      if mode!='auto': continue
      key = (str(layer.weight.device),*layer.weight.shape,phase)
      if key not in decisions:
        # Use nonconstant activations and the actual weights; realize and synchronize
        # both candidates so transfer/packing costs cannot be hidden in a lazy graph.
        assert isinstance(layer.weight.device,str)
        if layer is getattr(model,'output',None): rows = 1 # Transformer prunes its head to the final token.
        x = (Tensor.rand(1,rows,layer.weight.shape[1],device=layer.weight.device)*.4-.2).realize()
        assert isinstance(x.device,str)
        original = TinyJit(lambda a:layer.source(a).realize())
        native = TinyJit(lambda a:layer.npu(a).realize())
        expected = original(x).flatten().tolist()
        actual = native(x).flatten().tolist()
        assert isinstance(expected,list) and isinstance(actual,list)
        error = max(abs(a-b) for a,b in zip(actual,expected))
        valid = all(math.isfinite(a) and math.isfinite(b) and abs(a-b)<=2e-3+3e-3*abs(b) for a,b in zip(actual,expected))
        timings = {}
        for name,fn in [('original',original),('npu',native)]:
          for _ in range(2): fn(x).realize()
          samples = []
          for _ in range(5):
            Device[x.device].synchronize()
            start = time.perf_counter()
            fn(x).realize()
            Device[x.device].synchronize()
            samples.append(time.perf_counter()-start)
          timings[name] = statistics.median(samples)
        decisions[key] = {'device':str(x.device),'shape':list(layer.weight.shape),'phase':phase,'valid':valid,'max_abs_error':error,
                          'original_ms':timings['original']*1000,'npu_ms':timings['npu']*1000,
                          'selected':valid and timings['npu']<timings['original']*.9}
      setattr(layer,phase,'on' if decisions[key]['selected'] else 'off')
    if layer.prefill==layer.decode=='off': layer.packed.clear()
  groups = []
  if fuse_projections:
    for block in getattr(model,'blk',[]):
      for name,attrs in [('attn_qkv',('attn_q','attn_k','attn_v')),('ffn_gate_up',('ffn_gate','ffn_up'))]:
        members = tuple(member for attr in attrs if isinstance(member:=getattr(block,attr,None),RockchipLinear))
        if len(members)!=len(attrs): continue
        if not any(all(getattr(layer,phase)=='on' for layer in members) for phase in ('prefill','decode')): continue
        if len({layer.weight.shape[1] for layer in members})!=1 or len({layer.bias is None for layer in members})!=1: continue
        group = RockchipProjections(members,tile_columns)
        setattr(block,name,group)
        groups.append(group)
  ffn_blocks = 0
  if fused_ffn:
    for block in getattr(model,'blk',[]):
      ffn_group,down = getattr(block,'ffn_gate_up',None),getattr(block,'ffn_down',None)
      config = getattr(block,'config',None)
      if (isinstance(ffn_group,RockchipProjections) and isinstance(down,RockchipLinear) and down.weight.device=='CPU'
          and down.depth%32==0 and config is not None and config.swiglu_limit is None
          and all(layer.columns==down.depth for layer in ffn_group.layers)):
        block.fused_ffn = RockchipFeedForward(ffn_group,down,split_down)
        ffn_blocks += 1
  # The final vocabulary projection is one row in both phases. Select by model
  # phase, rather than treating every one-row kernel as a decode operation.
  def in_phase(jit, phase):
    variants:dict[tuple,_TinyJit] = {}
    def run(*args, **kwargs):
      selected = jit
      if phase=='prefill' and native_replay and isinstance(jit,_TinyJit) and jit.fxn is not None:
        key = tuple((arg.device,arg.dtype,arg.max_shape) for arg in (*args,*kwargs.values()) if isinstance(arg,Tensor))
        if key not in variants:
          variants[key] = jit if not variants else TinyJit(jit.fxn,prune=jit.prune)
          if len(variants)>8: variants.pop(next(iter(variants)))
        selected = variants[key]
      for layer in layers: layer.phase = phase
      try:
        result = selected(*args, **kwargs)
        if native_replay and getattr(selected,'captured',None) is not None:
          from tinygrad.llm.kernels.rockchip_replay import RockchipCapturedJit
          if not isinstance(selected.captured,RockchipCapturedJit): selected.captured = RockchipCapturedJit(selected.captured)
        return result
      finally:
        for layer in layers: layer.phase = None
    return run
  for phase, attr in [('prefill','prefill_jit'),('decode','rollout_jit'),
                      ('prefill','greedy_prefill_jit'),('decode','greedy_rollout_jit')]:
    if hasattr(model,attr): setattr(model,attr,in_phase(getattr(model,attr),phase))
  attention_blocks,prepared_blocks = 0,0
  if cpu_attention:
    from tinygrad.llm.kernels.rockchip_cpu import decode_attention, prefill_attention
    from tinygrad.llm.model import TransformerBlock
    for block in getattr(model,'blk',[]):
      config = getattr(block,'config',None)
      projection = getattr(block,'attn_q',None)
      if (isinstance(block,TransformerBlock) and config is not None and isinstance(projection,RockchipLinear)
          and projection.weight.device=='CPU' and 4<=config.head_dim<=256 and config.head_dim%4==0 and 1<=config.max_context<=4096
          and not config.sliding_window and not config.attn_sinks and not config.attn_output_gate):
        block.decode_attention = decode_attention
        block.prefill_attention = prefill_attention
        attention_blocks += 1
        qkv_group = getattr(block,'attn_qkv',None)
        query_weight,key_weight = getattr(getattr(block,'attn_q_norm',None),'weight',None),getattr(getattr(block,'attn_k_norm',None),'weight',None)
        if (fused_qkv and isinstance(qkv_group,RockchipProjections) and config.qk_norm==config.head_dim==config.rope_dim
            and 8<=config.head_dim<=256 and config.head_dim%8==0 and 1<=config.n_kv_heads<=config.n_heads<=128
            and isinstance(query_weight,Tensor) and isinstance(key_weight,Tensor)
            and all(w.device=='CPU' and w.dtype in (dtypes.half,dtypes.float) for w in (query_weight,key_weight))):
          setattr(block,'prepared_qkv',RockchipPreparedQKV(qkv_group,config.n_heads,query_weight,key_weight,config.norm_eps))
          prepared_blocks += 1
  norms = 0
  if cpu_norm:
    for obj,name in [*((block,name) for block in getattr(model,'blk',[]) for name in ('attn_norm','ffn_norm')),(model,'output_norm')]:
      source = getattr(obj,name,None)
      if isinstance(source,nn.RMSNorm) and source.weight is not None and source.weight.device=='CPU':
        setattr(obj,name,RockchipRMSNorm(source))
        norms += 1
  return {'layers':len(layers),'fused_groups':len(groups),'tile_columns':tile_columns,'cpu_attention_blocks':attention_blocks,
          'native_replay':native_replay,'fused_ffn_blocks':ffn_blocks,'prepared_qkv_blocks':prepared_blocks,'cpu_norms':norms,
          'decode_layers':sum(l.decode=='on' for l in layers),
          'prefill_layers':sum(l.prefill=='on' for l in layers),'decisions':list(decisions.values())}
