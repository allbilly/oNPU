import unittest
from types import SimpleNamespace
import numpy as np
from tinygrad import Tensor, TinyJit
from tinygrad.llm.kernels.rockchip_replay import RockchipCapturedJit
from tinygrad.llm.kernels.rockchip import configure


class TestRockchipReplayFallback(unittest.TestCase):
  def test_prefill_variants_reuse_multiple_input_sizes(self):
    model = SimpleNamespace(blk=[],greedy_prefill_jit=TinyJit(lambda x:(x*2+1).realize()))
    configure(model,native_replay=True)
    for rows in (16,32,64,16,32,64,16,32,64,16,64):
      values = np.arange(rows*8,dtype=np.float32).reshape(1,rows,8)
      actual = model.greedy_prefill_jit(Tensor(values,device='CPU').realize()).numpy()
      np.testing.assert_array_equal(actual,values*2+1)

  def test_cpu_only_graph_uses_original_executor(self):
    run = TinyJit(lambda x:(x*2+1).realize())
    for i in range(3): run(Tensor([float(i)],device='CPU').realize())
    run.captured = RockchipCapturedJit(run.captured)
    for i in range(3,7):
      np.testing.assert_array_equal(run(Tensor([float(i)],device='CPU').realize()).numpy(),[i*2+1])
    self.assertEqual(run.captured.reason,'no NPU work')
    self.assertEqual(run.captured.native_runs,0)


if __name__=='__main__': unittest.main()
