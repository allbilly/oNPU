# Selective Rockchip inference for oNPU

OpenCL GPU serving is the default. Optional NPU assistance is selected separately
for prefill and decode, and independent workers can serve a GPU model alongside
a smaller CPU/NPU model. The retained code does not depend on either reference
worktree. Full operator coverage and arbitrary pure-NPU execution are outside
this inference-focused port.

## Retained paths

- `tinygrad/runtime/ops_rockchip.py` executes bounded FP16 matrix operations with
  FP32 accumulation, three-core column sharding, reusable command buffers and
  per-buffer cache barriers. Inputs and weights must be finite; all 65536 half
  encodings, vector lanes, unaligned starts and tails are tested. A worker holds
  exclusive NPU ownership for its lifetime.
- `tinygrad/llm/kernels/rockchip.py` provides independent phase placement, shared
  QKV/gate-up projections, optional FFN-down K splitting and CPU normalization.
  Auto placement includes transfers and requires valid outputs plus a 10% median
  layer improvement. Other operations stay on the original CPU/OpenCL device.
- CPU kernels implement causal attention, grouped-query decode, Q/K normalization,
  RoPE and KV writes. SwiGLU reads native projection tiles directly and produces
  the same FP16 packed activation bytes as the normal tensor expression.
- Guarded native replay removes Python dispatch from prepared CPU/NPU graphs.
  It retains ownership, storage, command and immutable-weight checks, rejects
  nonfinite inputs before submission, and falls back for unsupported graphs.
- Optional native integration caches bounded prefill graph variants. The app
  chooses 1/32/64/128/256-token chunks that fit the context, warms both greedy and
  sampled paths, and checks cancellation between chunks and decode operations.
  GPU-only serving retains its normal batching.

The NPU is a dense FP16 matrix path with K up to4096, input tiles within four
CBUF banks and at most64 rows per core. Split-K FFN-down sums three FP32 partials
on CPU. These limits do not qualify every model or context. The unused linked
NPU-attention prototype was archived after transfer-inclusive timing failed to
justify selection for fresh prompts.

## Matched FP16 results

The `paired-final-v7` source snapshot compares Qwen3-0.6B at context512 against
RKLLM1.3.1 using the same effective FP16 checkpoint, raw input IDs, empty history,
32 greedy output IDs and ignored EOS. Loading and four complete warmups are
excluded; each fresh process supplies three measurements. Engine order is ABBA
at128 inputs and reversed at256. CPU affinity is4–7; sampled big-core CPU, NPU and
DDR frequencies are1.8 GHz,1 GHz and2.112 GHz. No global clock settings changed.

| Input tokens | tinygrad first token | RKLLM first token | tinygrad decode | RKLLM decode |
| ---: | ---: | ---: | ---: | ---: |
| 128 | 280.353 ms | 326.310 ms | 18.7022 tokens/s | 16.6705 tokens/s |
| 256 | 631.830 ms | 655.672 ms | 17.0492 tokens/s | 16.5525 tokens/s |

Every complete generated sequence agrees across engines and requests. Independent
full-output hardware checks and full-vocabulary logit comparisons also pass.
RKLLM masks EOS ID151645 when ignore_eos_token is enabled; all151935 remaining
logits are compared numerically, with that mask recorded separately.

These results establish the tested FP16 snapshot, not W8A8 performance or a
universal claim across models. Adaptive-worker and source qualification passed, including real GPU/NPU HTTP,
concurrent sessions and Chromium lifecycle/navigation checks. Details are
tracked in [the work record](rockchip-full-port.md). Full trials, checksums and
clock samples are retained in [the evidence record](rockchip-inference-progress.json).
The earlier [GPU auto-placement study](rockchip-onpu-benchmark.json) uses Q8 GGUF
and is a separate comparison.

## Verification and reproduction

Current checks:18 backend tests,24 generation/parser/tokenizer checks,23 app unit
tests, mypy219 source files, Ruff and Git whitespace checks. Tests use -n12 in the
tinygrad checkout. The optional OpenAI-client server fixtures cannot initialize
because that client package is absent; real application HTTP/browser verification
is recorded separately. No test or dependency was altered to conceal that limit.

To repeat the matched board experiment after installing the pinned checkpoint
and RKLLM artifacts at the paths in the runner:

```sh
.venv/bin/python extra/rockchip/compare_rkllm.py --report-dir /tmp/onpu-comparison --split-down --fused-qkv --cpu-norm
```

Use one NPU owner at a time. Unload an idle NPU app session before standalone
hardware measurements. Existing GPU sessions can remain loaded, but run timing
without concurrent generation or hardware tests. Both reference worktrees remain
intact and their uncommitted changes have not been discarded.

The local app remains available at http://127.0.0.1:8091 with GPU and CPU/NPU
sessions ready. Cold preparation of the NPU worker took about152 seconds while
warming all prompt sizes and both sampling modes. Exported evidence and source
review artifacts are in ~/oNPU/docs/rk3588-verification-20261018/.
